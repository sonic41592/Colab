# vapoursynth
*A video processing framework with simplicity in mind*

**Looking for the documentation?**  
Read the documentation here: [VapourSynth Documentation](http://vapoursynth.com/doc)

## Building
On **Windows**, follow the build instructions provided in [`build instructions windows.md`](https://github.com/vapoursynth/vapoursynth/blob/master/build%20instructions%20windows.md)  
On **Linux** and **Mac OS**, follow the build instructions provided in [Linux and OS X Compilation Instructions](http://vapoursynth.com/doc/installation.html#linux-and-os-x-compilation-instructions)
