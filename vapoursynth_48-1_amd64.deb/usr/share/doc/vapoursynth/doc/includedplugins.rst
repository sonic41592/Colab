Included Plugins
================

The source code for these plugins can be found in the VapourSynth source
tree. Many of them are included in the Windows installer in DLL form.

.. toctree::
   :maxdepth: 2
   :glob:

   plugins/*
