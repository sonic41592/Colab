FrameProps (Text)
=================

.. function:: FrameProps(clip clip[, string props=[], int alignment=7])
   :module: text

   Prints all properties attached to the frames, or if the *props* array is
   given only those properties.

   This is a convenience function for *Text*.
