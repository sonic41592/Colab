FlipVertical/FlipHorizontal
===========================

.. function:: FlipVertical(clip clip)
              FlipHorizontal(clip clip)
   :module: std

   Flips the clip in the vertical or horizontal direction.
