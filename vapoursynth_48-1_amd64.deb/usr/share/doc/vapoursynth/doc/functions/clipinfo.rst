ClipInfo (Text)
===============

.. function:: ClipInfo(clip clip[, int alignment=7])
   :module: text

   Prints information about the *clip*, such as the format and framerate.

   This is a convenience function for *Text*.
